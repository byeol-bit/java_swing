import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.util.Random;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Color;

public class StudyWords extends JDialog implements ActionListener{

	private final JPanel contentPanel = new JPanel();
	private JTextField txt_answer;
	private JButton btn_easy, btn_soso, btn_hard, btn_enter, btn_answer;
	private JLabel lbl_question, lbl_answer;
	private WordLists lists = new WordLists();
	private String[] array = new String[100];
	private String[] array2 = new String[100];
	private int arrCount = 0;
	private int flag = 0;
	private int num = 0;
	private int[] numArr = new int[100];
	private int numCount = 0;
	private int enterCount = 0;
	public StudyWords(WordNote w) 
	{
		getContentPane().setFont(new Font("����", Font.BOLD, 18));
		lists = w.notes;
		for(int i = 0; i < lists.getwCount(); i++)
		{
			array[arrCount] = lists.wLists[i].getWord();
			array2[arrCount++] = lists.wLists[i].getMeans();
		}
		
		setBounds(100, 100, 739, 452);
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		getContentPane().setLayout(null);
		
		btn_easy = new JButton("�ʱ�");
		btn_easy.addActionListener(this);
		btn_easy.setBounds(29, 39, 125, 48);
		getContentPane().add(btn_easy);
		
		btn_soso = new JButton("�߱�");
		btn_soso.addActionListener(this);
		btn_soso.setBounds(29, 110, 125, 48);
		getContentPane().add(btn_soso);
		
		btn_hard = new JButton("����");
		btn_hard.addActionListener(this);
		btn_hard.setBounds(29, 184, 125, 48);
		getContentPane().add(btn_hard);
		
		txt_answer = new JTextField();
		txt_answer.setBounds(175, 261, 314, 40);
		getContentPane().add(txt_answer);
		txt_answer.setColumns(10);
		
		btn_enter = new JButton("�Է�");
		btn_enter.addActionListener(this);
		btn_enter.setBounds(522, 256, 125, 48);
		getContentPane().add(btn_enter);
		
		lbl_question = new JLabel("");
		lbl_question.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_question.setFont(new Font("����", Font.PLAIN, 24));
		lbl_question.setBounds(239, 68, 307, 61);
		getContentPane().add(lbl_question);
		
		btn_answer = new JButton("���亸��");
		btn_answer.addActionListener(this);
		btn_answer.setBounds(522, 319, 125, 48);
		getContentPane().add(btn_answer);
		
		lbl_answer = new JLabel("");
		lbl_answer.setForeground(Color.RED);
		lbl_answer.setFont(new Font("Gulim", Font.PLAIN, 18));
		lbl_answer.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_answer.setBounds(150, 321, 339, 40);
		getContentPane().add(lbl_answer);
		
		JLabel lbl_word = new JLabel("\uB2E8\uC5B4 : ");
		lbl_word.setFont(new Font("����", Font.PLAIN, 24));
		lbl_word.setBounds(187, 68, 96, 61);
		getContentPane().add(lbl_word);
	}
	public void question()
	{
		Random r = new Random();
		num = r.nextInt(arrCount);
		for(int i = 0; i < numCount; i++)
		{
			while(true)
			{
				if(numArr[i] == num)
					num = r.nextInt(arrCount);
				else
					break;
			}

		}
		numArr[numCount++] = num;
		lbl_question.setText(array[num]);
	}
	public void actionPerformed(ActionEvent e) 
	{
		if(e.getSource() == btn_easy)
		{
			lbl_answer.setText("");
			
			JOptionPane.showMessageDialog(null, "�ʱ� ����.");
			numCount = 0; enterCount = 0;
			for(int i = 0; i < arrCount; i++)
			{
				array[i] = "";
				array2[i] = "";
			}
			
			arrCount = 0;
			
			for(int i = 0; i < lists.getwCount(); i++)
			{
				if(lists.wLists[i].getWord().length() <= 4)
					{
						array[arrCount] = lists.wLists[i].getWord();
						array2[arrCount++] = lists.wLists[i].getMeans();
					}
			}
			if(arrCount == 0)
			{
				JOptionPane.showMessageDialog(null, "�ʱ� �ܾ �����ϴ�.");
				return;
			}
			question();
		}
		else if(e.getSource() == btn_soso)
		{
			lbl_answer.setText("");
			
			JOptionPane.showMessageDialog(null, "�߱� ����.");
			numCount = 0; enterCount = 0;
			for(int i = 0; i < arrCount; i++)
			{
				array[i] = "";
				array2[i] = "";
			}
			
			arrCount = 0;
			
			for(int i = 0; i < lists.getwCount(); i++)
			{
				if(lists.wLists[i].getWord().length() >= 5 && lists.wLists[i].getWord().length() <= 7)
					{
						array[arrCount] = lists.wLists[i].getWord();
						array2[arrCount++] = lists.wLists[i].getMeans();
					}
			}
			if(arrCount == 0)
			{
				JOptionPane.showMessageDialog(null, "�߱� �ܾ �����ϴ�.");
				return;
			}
			question();
		}
		else if(e.getSource() == btn_hard)
		{
			lbl_answer.setText("");
			
			JOptionPane.showMessageDialog(null, "���� ����.");
			numCount = 0; enterCount = 0;
			for(int i = 0; i < arrCount; i++)
			{
				array[i] = "";
				array2[i] = "";
			}
			
			arrCount = 0;
			
			for(int i = 0; i < lists.getwCount(); i++)
			{
				if(lists.wLists[i].getWord().length() >= 8)
					{
						array[arrCount] = lists.wLists[i].getWord();
						array2[arrCount++] = lists.wLists[i].getMeans();
					}
			}
			if(arrCount == 0)
			{
				JOptionPane.showMessageDialog(null, "���� �ܾ �����ϴ�.");
				return;
			}
			question();
		}
		else if(e.getSource() == btn_enter)
		{
			lbl_answer.setText("");
			
			if(txt_answer.getText().equals(array2[num]))
			{
				JOptionPane.showMessageDialog(null, "���� �Դϴ�.");
				enterCount++;
				if(enterCount == arrCount)
					{
						JOptionPane.showMessageDialog(null, "�ܾ ��� �����ϼ˽��ϴ�.");
						return;
					}
				question();
			}
			else
				JOptionPane.showMessageDialog(null, "�����Դϴ�.");
		}
		else if(e.getSource() == btn_answer)
		{
			lbl_answer.setText(array2[num]);
		}
	}
}
