import java.util.Vector;

public class Words {
	
	private String word;
	private String means;
	private String check;
	
	public String getWord() {return word;}
	public String getMeans() {return means;}
	public String getCheck() {return check;}
	public void setCheck(String s) {check = s;}
	public Words(String word, String means, String check)
	{
		this.word = word;
		this.means = means;
		this.check = check;
	}
	
	public Vector<Object> wordLists() { // ���׸� ����
		Vector<Object> myvector = new Vector<Object>();
		myvector.add(word);
		myvector.add(means);
		return myvector;
	}
	
	public Vector<Object> learnLists() { // ���׸� ����
		Vector<Object> myvector = new Vector<Object>();
		myvector.add(word);
		myvector.add(means);
		myvector.add(check);
		return myvector;
	}

}
