import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPopupMenu;
import java.awt.Component;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;

public class MyWords extends JDialog implements ActionListener {

	private final JPanel contentPanel = new JPanel();
	private JLabel lbl_note, lbl_count;
	private JButton btn_unknown, btn_known, btn_delete;
	private DefaultTableModel model, model2;
	private JTable table;
	private int tableCount = 0;
	private JScrollPane scrollPane;
	private JPopupMenu popupMenu;
	private JMenuItem pop_learn, pop_miss, pop_delete;
	private String category2[] = {"�ܾ�", "��"};
	private String category[] = {"�ܾ�", "��", "�ϱ⿩��"};
	private WordLists lists = new WordLists();
	private JButton btn_all;

	public MyWords(WordNote w) 
	{
		lists = w.notes;		
		
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		
		setBounds(100, 100, 559, 595);
		getContentPane().setLayout(null);
		
		model = new DefaultTableModel(category,0);
		table = new JTable(model);
		table.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		scrollPane = new JScrollPane(table);
		scrollPane.setBounds(17, 66, 265, 271);		
		getContentPane().add(scrollPane);
		
		popupMenu = new JPopupMenu();
		addPopup(table, popupMenu);
		
		pop_learn = new JMenuItem("�ܿ�");
		pop_learn.addActionListener(this);
		popupMenu.add(pop_learn);
		
		pop_miss = new JMenuItem("�����");
		pop_miss.addActionListener(this);
		popupMenu.add(pop_miss);
		
		pop_delete = new JMenuItem("����");
		pop_delete.addActionListener(this);
		popupMenu.add(pop_delete);
		
		lbl_note = new JLabel("�ܾ���");
		lbl_note.setBounds(42, 15, 125, 36);
		getContentPane().add(lbl_note);
		
		btn_unknown = new JButton("�𸣴� �ܾ ����");
		btn_unknown.addActionListener(this);
		btn_unknown.setBounds(321, 56, 199, 54);
		getContentPane().add(btn_unknown);
		
		btn_known = new JButton("�ƴ� �ܾ ����");
		btn_known.addActionListener(this);
		btn_known.setBounds(321, 141, 199, 54);
		getContentPane().add(btn_known);
		
		btn_all = new JButton("��� �ܾ� ����");
		btn_all.addActionListener(this);
		btn_all.setBounds(321, 224, 199, 54);
		getContentPane().add(btn_all);
		
		btn_delete = new JButton("����");
		btn_delete.addActionListener(this);
		btn_delete.setBounds(321, 308, 199, 54);
		getContentPane().add(btn_delete);
		
		lbl_count = new JLabel("0/100");
		lbl_count.setBounds(27, 352, 78, 21);
		getContentPane().add(lbl_count);
		refresh();
	}
	
	public void refresh()
	{

			model = new DefaultTableModel(category, 0);
			for(int i = 0; i < lists.getwCount(); i++)
			{			
				model.addRow(lists.wLists[i].learnLists());
			}
			table.setModel(model);
			lbl_count.setText(lists.getwCount() + "/100");
	}

	public void actionPerformed(ActionEvent e) 
	{
		if(e.getSource() == pop_learn)
		{
			int[] num = table.getSelectedRows();
			for(int i = 0; i < num.length; i++)
			{
				if(num[i] >= 0)
				{
					String w = (String)table.getValueAt(num[i], 0);
					String m = (String)table.getValueAt(num[i], 1);
					
					for(int j = 0; j < lists.getlCount(); j++)
					{
						if(lists.lLists[j].getWord().equals(w))
						{
							JOptionPane.showMessageDialog(null, "������ �ܾ �����մϴ�.");
							return;
						}
					}
					lists.learningWord(w, m);
					refresh();
				}					
			}
			JOptionPane.showMessageDialog(null, "�ϱ� �ܾ�� ��ϵ˴ϴ�.");						
		}
		
		else if(e.getSource() == pop_miss)
		{
			int[] num = table.getSelectedRows();
			
			for(int j = 0; j < num.length; j++)
			{
				if(num[j] >= 0)
				{
					String w = (String)table.getValueAt(num[j], 0);
					String m = (String)table.getValueAt(num[j], 1);
					
					if(lists.wLists[num[j]].getCheck() == " ")
					{
						//JOptionPane.showMessageDialog(null, "�ϱ��� �ܾ '�����'�� �����Ҽ� �ֽ��ϴ�.");
						return;
					}
					
					for(int i = 0; i < lists.getlCount(); i++)
					{
						if(lists.lLists[i].getWord().equals(w))
						{
							lists.deleteLearnWord(w);
						}
							
					}
					lists.wLists[num[j]].setCheck(" ");
					refresh();
				}
			}
		}
		else if(e.getSource() == pop_delete)
		{
			int[] num = table.getSelectedRows();
			for(int i = 0; i < num.length; i++)
			{
				if(num[i] >= 0)
				{
					String str = (String)table.getValueAt(num[i], 0);
					
					for(int j = num[i]; j < lists.getwCount(); j++)
					{
						lists.wLists[j] = lists.wLists[j+1];
					}
					lists.setwCount();
					refresh();
					JOptionPane.showMessageDialog(null, "�����Ͽ����ϴ�.");
					
					lists.deleteLearnWord(str);
				}
			}
		}
		else if(e.getSource() == btn_delete)
		{
			int[] num = table.getSelectedRows();
			if(num.length == 0)
			{
				JOptionPane.showMessageDialog(null, "�ܾ ������ �ּ���.");
				return;
			}
			for(int i = 0; i < num.length; i++)
			{
				if(num[i] >= 0)
				{
					String str = (String)table.getValueAt(num[i], 0);
					
					for(int j = num[i]; j < lists.getwCount(); j++)
					{
						lists.wLists[j] = lists.wLists[j+1];
					}
					lists.setwCount();
					refresh();
					JOptionPane.showMessageDialog(null, "�����Ͽ����ϴ�.");
					
					lists.deleteLearnWord(str);
				}
			}			
		}
		
		else if(e.getSource() == btn_known)
		{
			model2 = new DefaultTableModel(category2, 0);
			
			if(lists.getlCount() == 0)
			{
				JOptionPane.showMessageDialog(null, "�ϱ��忡 �ܾ �������� �ʽ��ϴ�.");
				return;
			}								
			
			for(int i = 0; i < lists.getlCount(); i++)
			{			
				model2.addRow(lists.lLists[i].wordLists());
			}
			table.setModel(model2);
			lbl_count.setText(lists.getlCount() + "/100");
		}
		else if(e.getSource() == btn_unknown)
		{
			model2 = new DefaultTableModel(category2, 0);
			
			if(lists.getwCount() == lists.getlCount())
			{
				JOptionPane.showMessageDialog(null, "�𸣴� �ܾ �������� �ʽ��ϴ�.");
				return;
			}				
			
			for(int i = 0; i < lists.getwCount(); i++)
			{
				if(lists.wLists[i].getCheck().equals(" "))
					model2.addRow(lists.wLists[i].wordLists());
			}
			table.setModel(model2);
			lbl_count.setText((lists.getwCount()-lists.getlCount()) + "/100");
		}
		else if(e.getSource() == btn_all)
		{
			if(lists.getwCount() == 0)
			{
				JOptionPane.showMessageDialog(null, "�ܾ��忡 �ܾ �������� �ʽ��ϴ�.");
				return;
			}
			refresh();
		}
	}
	private static void addPopup(Component component, final JPopupMenu popup) {
		component.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				if (e.isPopupTrigger()) {
					showMenu(e);
				}
			}
			public void mouseReleased(MouseEvent e) {
				if (e.isPopupTrigger()) {
					showMenu(e);
				}
			}
			private void showMenu(MouseEvent e) {
				popup.show(e.getComponent(), e.getX(), e.getY());
			}
		});
	}
}
