import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.border.EmptyBorder;

import java.awt.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;
import java.util.List;
import javax.swing.*;

public class WordNote extends JFrame implements ActionListener{

	private JPanel contentPane, pn_find, pn_word;
	private JButton btn_find, btn_add, btn_word, btn_study, btn_exit;
	private JPanel pn_study;
	private JComboBox cmb_findWord;
	private JLabel lbl_findWord;
	private JTextField field;
	public String[] words;
	public String[] means;
	private JLabel lbl_answer;
	private MyWords myWords;
	public WordLists notes = new WordLists();
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) 
	{
		WordNote frame = new WordNote();
		frame.setVisible(true);
	}

	/**
	 * Create the frame.
	 */
	public WordNote() {
		read();
		notes.readW();
		notes.readL();
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 979, 494);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		pn_find = new JPanel();
		pn_find.setBounds(216, 15, 724, 402);
		contentPane.add(pn_find);
		pn_find.setLayout(null);
		
		btn_add = new JButton("�߰�");
		btn_add.addActionListener(this);
		btn_add.setBounds(529, 245, 155, 48);
		pn_find.add(btn_add);
		
		cmb_findWord = makeComboBox(words);
		
		cmb_findWord.setBounds(175, 71, 347, 27);
		pn_find.add(cmb_findWord);
		cmb_findWord.setEditable(true);
		cmb_findWord.setSelectedIndex(-1);		
		cmb_findWord.addActionListener(this);
		
        field = (JTextField) cmb_findWord.getEditor().getEditorComponent();
        field.setText("");
        field.addKeyListener(new ComboKeyHandler(cmb_findWord));        
		
		lbl_findWord = new JLabel("ã�� �ܾ� : ");
		lbl_findWord.setFont(new Font("����", Font.PLAIN, 20));
		lbl_findWord.setBounds(42, 66, 116, 37);
		pn_find.add(lbl_findWord);
		
		lbl_answer = new JLabel("");
		lbl_answer.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_answer.setFont(new Font("����", Font.PLAIN, 24));
		lbl_answer.setBounds(40, 224, 472, 69);
		pn_find.add(lbl_answer);
		
		btn_exit = new JButton("����");
		btn_exit.addActionListener(this);
		btn_exit.setBounds(529, 320, 155, 48);
		pn_find.add(btn_exit);
		
		pn_word = new JPanel();
		pn_word.setBounds(216, 15, 724, 396);
		contentPane.add(pn_word);
		
		btn_word = new JButton("�ܾ��� ����");
		btn_word.addActionListener(this);
		btn_word.setBounds(17, 85, 155, 48);
		contentPane.add(btn_word);
		
		btn_study = new JButton("�ܾ� �����ϱ�");
		btn_study.addActionListener(this);
		btn_study.setBounds(17, 148, 155, 48);
		contentPane.add(btn_study);
		
		pn_study = new JPanel();
		pn_study.setBounds(216, 15, 724, 408);
		contentPane.add(pn_study);
	}
	private static JComboBox makeComboBox(String... model) {
        return new JComboBox(model);
        
    }

	public void actionPerformed(ActionEvent e) 
	{
		try
		{
			if(e.getSource() == btn_word)
			{
				MyWords d = new MyWords(this);
				d.setVisible(true);
			}
			else if(e.getSource() == btn_study)
			{
				StudyWords s = new StudyWords(this);
				s.setVisible(true);
			}
			else if(e.getSource() == btn_add)
			{
				String w = (String)cmb_findWord.getSelectedItem();
				
				for(int i = 0; i < notes.getwCount(); i++)
				{
					if(notes.wLists[i].getWord().equals(w))
					{
						JOptionPane.showMessageDialog(null, "������ �ܾ �����մϴ�.");
						return;
					}
				}
				int num = 0;
				for(int i = 0; i < words.length; i++)
				{
					if(words[i].equals(w))
						num = i;
				}	
				notes.insertWord(w, means[num]);
			}
			else if (e.getSource() == btn_exit)
			{
				notes.writeW();
				notes.writeL();
				System.exit(0);					
			}
			else if(e.getSource() == cmb_findWord)
			{
				String str = (String)cmb_findWord.getSelectedItem();
				for(int i = 0; i < words.length; i++)
				{
					if(words[i].equals(str))
						lbl_answer.setText(means[i]);
				}			
			}
		}
		catch(NullPointerException p)
		{
			
		}
		
	}
	public void read()
	{       
		try {
			 BufferedReader reader = new BufferedReader(new FileReader("EK57873.txt"));		 		
			 
		String data = "";
		int num = Integer.parseInt(reader.readLine());
		words = new String[num];
		means = new String[num];
        int index = 0;
		
        // readLine ����� �� ���ξ� �о���δ�    
		while ((data = reader.readLine()) != null) 
		{
			String[] str = data.split(" ///");
			words[index] = str[0];
			means[index++] = str[1];
		}			
		reader.close();
		
			
	}catch (FileNotFoundException e) { // ������ ���� �� �������� ������ FileNotFoundException ���ܸ� �߻�
				//e.printStackTrace();
	}catch (IOException e) { // ������ �� �� ��ΰ� �������� ������ IOException �� �߻�
			e.printStackTrace();
		}
	}
}

class ComboKeyHandler extends KeyAdapter {
    private final JComboBox<String> comboBox;
    private final List<String> list = new ArrayList<>();
    private boolean shouldHide;

    public ComboKeyHandler(JComboBox<String> combo) {
        super();
        this.comboBox = combo;
        for (int i = 0; i < comboBox.getModel().getSize(); i++) {
            list.add((String) comboBox.getItemAt(i));
        }
    }
    @Override public void keyTyped(final KeyEvent e) {
        EventQueue.invokeLater(new Runnable() {
            @Override public void run() {
                String text = ((JTextField) e.getComponent()).getText();
                ComboBoxModel<String> m;
                if (text.isEmpty()) {
                    String[] array = list.toArray(new String[list.size()]);
                    m = new DefaultComboBoxModel<String>(array);
                    setSuggestionModel(comboBox, m, "");
                    comboBox.hidePopup();
                } else {
                    m = getSuggestedModel(list, text);
                    if (m.getSize() == 0 || shouldHide) {
                        comboBox.hidePopup();
                    } else {
                        setSuggestionModel(comboBox, m, text);
                        comboBox.showPopup();
                    }
                }
            }
        });
    }
    @Override public void keyPressed(KeyEvent e) {
        JTextField textField = (JTextField) e.getComponent();
        String text = textField.getText();
        shouldHide = false;
        switch (e.getKeyCode()) {
          case KeyEvent.VK_RIGHT:
            for (String s: list) {
                if (s.startsWith(text)) {
                    textField.setText(s);
                    return;
                }
            }
            break;
          case KeyEvent.VK_ENTER:
            if (!list.contains(text)) {
                //list.add(text);
            	JOptionPane.showMessageDialog(null, "���� �ܾ��Դϴ�.");
                Collections.sort(list);
                //setSuggestionModel(comboBox, new DefaultComboBoxModel(list), text);
                setSuggestionModel(comboBox, getSuggestedModel(list, text), text);
            }
            shouldHide = true;
            break;
          case KeyEvent.VK_ESCAPE:
            shouldHide = true;
            break;
          default:
            break;
        }
    }
    private static void setSuggestionModel(JComboBox<String> comboBox, ComboBoxModel<String> mdl, String str) {
        comboBox.setModel(mdl);
        comboBox.setSelectedIndex(-1);
        ((JTextField) comboBox.getEditor().getEditorComponent()).setText(str);
    }
    private static ComboBoxModel<String> getSuggestedModel(List<String> list, String text) {
        DefaultComboBoxModel<String> m = new DefaultComboBoxModel<>();
        for (String s: list) {
            if (s.startsWith(text)) {
                m.addElement(s);
            }
        }
        return m;
    }
}
